(function (){
	var button1 = document.getElementById('firstButton');
	var button2 = document.getElementById('secondButton');
	
	button1.addEventListener('click', function() { 	  
        tau.changePage("#second");
     });
    
    

     button2.addEventListener('click', function() {
   	 
        tau.changePage("#third");
   	 
     });
     
     window.addEventListener( 'tizenhwkey', function( ev ) {
		if( ev.keyName === "back" ) {
			var page = document.getElementsByClassName( 'ui-page-active' )[0],
				pageid = page ? page.id : "";
			if( pageid === "main" ) {
				try {
					tizen.application.getCurrentApplication().exit();
				} catch (ignore) {
				}
			} else {
				window.history.back();
			}
		}
	} );
     
     var SCROLL_STEP = 120;       // distance of moving scroll for each rotary event

     document.addEventListener("pagebeforeshow", function pageScrollHandler(e) {
         var page = e.target;
         elScroller = page.querySelector(".ui-scroller");

         // rotary event handler
         rotaryEventHandler = function(e) {
             if (elScroller) {
                 if (e.detail.direction === "CW") { // Right direction
                     elScroller.scrollTop += SCROLL_STEP;
                 } else if (e.detail.direction === "CCW") { // Left direction
                     elScroller.scrollTop -= SCROLL_STEP;
                 }
             }
         };

         // register rotary event.
         document.addEventListener("rotarydetent", rotaryEventHandler, false);

         // unregister rotary event
         page.addEventListener("pagebeforehide", function pageHideHanlder() {
             page.removeEventListener("pagebeforehide", pageHideHanlder, false);
             document.removeEventListener("rotarydetent", rotaryEventHandler, false);
         }, false);
     }, false);
} () );